import { describe, expect, it } from 'vitest';
import { createMemoryStore } from '../src/store/memoryStore.js';
import { canPerform } from '../src/auth/rbac.js';

describe('multi-tenant clinic model', () => {
  it('allows one tenant to own multiple branches while patients stay tenant-wide', async () => {
    const store = createMemoryStore();
    const tenant = await store.createTenant({ name: 'Celon Dental Clinic', slug: 'celon-dental' });
    const lekki = await store.createBranch({ tenantId: tenant.id, name: 'Lekki Branch', address: 'Lekki' });
    const ikeja = await store.createBranch({ tenantId: tenant.id, name: 'Ikeja Branch', address: 'Ikeja' });
    const patient = await store.createPatient({ tenantId: tenant.id, firstName: 'Mary', lastName: 'Johnson', phone: '+2348012345678' });
    await store.createAppointment({ tenantId: tenant.id, branchId: lekki.id, patientId: patient.id, startsAt: '2026-09-08T09:00:00.000Z', serviceName: 'Dental Cleaning' });
    await store.createAppointment({ tenantId: tenant.id, branchId: ikeja.id, patientId: patient.id, startsAt: '2026-09-15T09:00:00.000Z', serviceName: 'Root Canal Follow-up' });

    const snapshot = await store.getTenantSnapshot(tenant.id);
    expect(snapshot.branches.map((b) => b.name)).toEqual(['Lekki Branch', 'Ikeja Branch']);
    expect(snapshot.patients).toHaveLength(1);
    expect(snapshot.appointments).toHaveLength(2);
    expect(snapshot.appointments.map((a) => a.branchId).sort()).toEqual([ikeja.id, lekki.id].sort());
  });

  it('scopes branch staff to assigned branch while owner sees all branches', async () => {
    const store = createMemoryStore();
    const tenant = await store.createTenant({ name: 'Celon Dental Clinic', slug: 'celon-dental' });
    const branchA = await store.createBranch({ tenantId: tenant.id, name: 'Branch A' });
    const branchB = await store.createBranch({ tenantId: tenant.id, name: 'Branch B' });
    const owner = await store.addMember({ tenantId: tenant.id, email: 'owner@example.com', role: 'owner' });
    const receptionist = await store.addMember({ tenantId: tenant.id, branchIds: [branchA.id], email: 'frontdesk@example.com', role: 'receptionist' });

    expect(await store.visibleBranchesForMember(owner.id)).toEqual([branchA, branchB]);
    expect(await store.visibleBranchesForMember(receptionist.id)).toEqual([branchA]);
  });
});

describe('RBAC permission matrix', () => {
  it('keeps owner/admin controls away from branch staff', () => {
    expect(canPerform('owner', 'manage_subscription')).toBe(true);
    expect(canPerform('owner', 'manage_staff')).toBe(true);
    expect(canPerform('branch_manager', 'manage_appointments')).toBe(true);
    expect(canPerform('receptionist', 'create_appointment')).toBe(true);
    expect(canPerform('receptionist', 'manage_subscription')).toBe(false);
    expect(canPerform('doctor', 'write_encounter')).toBe(true);
    expect(canPerform('doctor', 'manage_staff')).toBe(false);
    expect(canPerform('accountant', 'view_billing')).toBe(true);
    expect(canPerform('accountant', 'write_encounter')).toBe(false);
  });
});
