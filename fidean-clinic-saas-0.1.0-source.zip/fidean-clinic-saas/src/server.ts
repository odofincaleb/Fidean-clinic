import Fastify from 'fastify';
import cors from '@fastify/cors';
import staticPlugin from '@fastify/static';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { z } from 'zod';
import { store } from './store/singleton.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const rootDir = join(__dirname, '..');

const tenantInput = z.object({ name: z.string().min(2), slug: z.string().min(2).regex(/^[a-z0-9-]+$/) });
const branchInput = z.object({ tenantId: z.string().min(1), name: z.string().min(2), address: z.string().optional(), phone: z.string().optional() });
const patientInput = z.object({ tenantId: z.string().min(1), firstName: z.string().min(1), lastName: z.string().optional(), phone: z.string().min(5), email: z.string().email().optional() });
const appointmentInput = z.object({ tenantId: z.string().min(1), branchId: z.string().min(1), patientId: z.string().min(1), startsAt: z.string().datetime(), serviceName: z.string().min(2), doctorMemberId: z.string().optional(), notes: z.string().optional() });

export function buildServer() {
  const app = Fastify({ logger: true });

  app.register(cors, { origin: true });
  app.register(staticPlugin, { root: join(rootDir, 'public'), prefix: '/' });

  app.get('/health', async () => ({ ok: true, service: 'fidean-clinic-saas', version: '0.1.0' }));

  app.post('/api/demo/celon', async () => ({ ok: true, snapshot: await store.seedCelonDemo() }));

  app.post('/api/tenants', async (request, reply) => {
    const input = tenantInput.parse(request.body);
    return reply.code(201).send({ ok: true, tenant: await store.createTenant(input) });
  });

  app.post('/api/branches', async (request, reply) => {
    const input = branchInput.parse(request.body);
    return reply.code(201).send({ ok: true, branch: await store.createBranch(input) });
  });

  app.post('/api/patients', async (request, reply) => {
    const input = patientInput.parse(request.body);
    return reply.code(201).send({ ok: true, patient: await store.createPatient(input) });
  });

  app.post('/api/appointments', async (request, reply) => {
    const input = appointmentInput.parse(request.body);
    return reply.code(201).send({ ok: true, appointment: await store.createAppointment(input) });
  });

  app.get('/api/tenants/:tenantId/snapshot', async (request) => {
    const params = z.object({ tenantId: z.string() }).parse(request.params);
    return { ok: true, snapshot: await store.getTenantSnapshot(params.tenantId) };
  });

  app.setErrorHandler((error, _request, reply) => {
    const typedError = error as Error & { statusCode?: number };
    const status = typedError.statusCode ?? 400;
    reply.code(status).send({ ok: false, error: typedError.message });
  });

  return app;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT ?? 4310);
  const host = process.env.HOST ?? '127.0.0.1';
  buildServer().listen({ port, host }).catch((error) => {
    console.error(error);
    process.exit(1);
  });
}
