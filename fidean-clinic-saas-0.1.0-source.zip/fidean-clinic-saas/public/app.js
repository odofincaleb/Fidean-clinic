const seed = document.querySelector('#seed');
const stats = document.querySelector('#stats');
const branches = document.querySelector('#branches');
const appointments = document.querySelector('#appointments');

function card(label, value) {
  return `<article class="stat"><strong>${value}</strong><span>${label}</span></article>`;
}

function render(snapshot) {
  stats.innerHTML = [
    card('Tenant', snapshot.tenant.name),
    card('Branches', snapshot.branches.length),
    card('Patients', snapshot.patients.length),
    card('Appointments', snapshot.appointments.length),
  ].join('');
  branches.innerHTML = snapshot.branches.map((branch) => `<article><h3>${branch.name}</h3><p>${branch.address || 'No address yet'}</p><small>${branch.id}</small></article>`).join('');
  appointments.innerHTML = snapshot.appointments.map((appt) => {
    const branch = snapshot.branches.find((item) => item.id === appt.branchId);
    const patient = snapshot.patients.find((item) => item.id === appt.patientId);
    return `<article><h3>${appt.serviceName}</h3><p>${patient?.firstName || 'Patient'} at ${branch?.name || 'Branch'}</p><small>${new Date(appt.startsAt).toLocaleString()}</small></article>`;
  }).join('');
}

seed.addEventListener('click', async () => {
  seed.disabled = true;
  seed.textContent = 'Loading demo...';
  const response = await fetch('/api/demo/celon', { method: 'POST' });
  const body = await response.json();
  render(body.snapshot);
  seed.textContent = 'Celon demo loaded';
});
