# Fidean Clinic SaaS

Standalone multi-tenant clinic SaaS foundation for Fidean Technologies.

## Current MVP v0.1.0

This is no longer a WordPress-dependent clinic system. It is a standalone SaaS scaffold with:

- Tenant = clinic group/business, e.g. Celon Dental Clinic.
- Branches under tenant, e.g. Lekki and Ikeja.
- Tenant-wide patients.
- Branch-specific appointments.
- Staff membership roles.
- Backend-first RBAC matrix.
- Fastify API.
- Static dashboard proof page.
- In-memory store for fast MVP/dev testing.

## Run locally

```bash
npm install
npm test
npm run build
npm run dev
```

Open:

```text
http://127.0.0.1:4310/
```

Smoke endpoints:

```bash
curl http://127.0.0.1:4310/health
curl -X POST http://127.0.0.1:4310/api/demo/celon
```

## API routes

- `GET /health`
- `POST /api/demo/celon`
- `POST /api/tenants`
- `POST /api/branches`
- `POST /api/patients`
- `POST /api/appointments`
- `GET /api/tenants/:tenantId/snapshot`

## Core roles

- owner
- admin
- branch_manager
- doctor
- receptionist
- nurse
- accountant
- viewer

## Next build phase

1. Replace in-memory store with PostgreSQL repository.
2. Add email/password auth and tenant membership resolver.
3. Build admin UI tables for branches, patients, services, appointments.
4. Add appointment status transitions.
5. Add booking public page per tenant/branch.
6. Add notifications: email first, WhatsApp/SMS later.
7. Add billing/Paystack only after explicit approval.
8. Add dental chart/treatment-plan module after core operations are stable.

## Clean-room rule

KiviCare was used only for market/workflow research. Do not copy KiviCare Pro/add-on source code, templates, assets, identifiers or licensing logic.
