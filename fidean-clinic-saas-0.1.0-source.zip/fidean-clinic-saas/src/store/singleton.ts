import { createMemoryStore } from './memoryStore.js';

export const store = createMemoryStore();
