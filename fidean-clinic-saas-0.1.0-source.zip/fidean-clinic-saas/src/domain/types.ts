export type Role = 'owner' | 'admin' | 'branch_manager' | 'doctor' | 'receptionist' | 'nurse' | 'accountant' | 'viewer';

export type Permission =
  | 'manage_subscription'
  | 'manage_staff'
  | 'manage_branches'
  | 'manage_appointments'
  | 'create_appointment'
  | 'view_patients'
  | 'write_encounter'
  | 'view_billing'
  | 'manage_billing'
  | 'view_reports';

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  status: 'active' | 'trial' | 'suspended';
  createdAt: string;
}

export interface Branch {
  id: string;
  tenantId: string;
  name: string;
  address?: string;
  phone?: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Member {
  id: string;
  tenantId: string;
  email: string;
  displayName?: string;
  role: Role;
  branchIds: string[];
  status: 'invited' | 'active' | 'revoked';
  createdAt: string;
}

export interface Patient {
  id: string;
  tenantId: string;
  patientCode: string;
  firstName: string;
  lastName?: string;
  phone: string;
  email?: string;
  createdAt: string;
}

export interface Service {
  id: string;
  tenantId: string;
  branchId?: string;
  name: string;
  durationMinutes: number;
  priceKobo: number;
  currency: 'NGN' | 'USD';
  active: boolean;
}

export interface Appointment {
  id: string;
  tenantId: string;
  branchId: string;
  patientId: string;
  doctorMemberId?: string;
  serviceName: string;
  startsAt: string;
  status: 'requested' | 'confirmed' | 'checked_in' | 'completed' | 'cancelled' | 'no_show';
  notes?: string;
  createdAt: string;
}

export interface TenantSnapshot {
  tenant: Tenant;
  branches: Branch[];
  members: Member[];
  patients: Patient[];
  appointments: Appointment[];
}
