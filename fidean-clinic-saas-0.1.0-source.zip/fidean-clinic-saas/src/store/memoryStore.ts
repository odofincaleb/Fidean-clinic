import { nanoid } from 'nanoid';
import type { Appointment, Branch, Member, Patient, Service, Tenant, TenantSnapshot } from '../domain/types.js';

function now(): string {
  return new Date().toISOString();
}

function patientCode(): string {
  return `PAT-${nanoid(8).toUpperCase()}`;
}

export interface MemoryStore {
  createTenant(input: { name: string; slug: string }): Promise<Tenant>;
  createBranch(input: { tenantId: string; name: string; address?: string; phone?: string }): Promise<Branch>;
  addMember(input: { tenantId: string; email: string; role: Member['role']; branchIds?: string[]; displayName?: string }): Promise<Member>;
  createPatient(input: { tenantId: string; firstName: string; lastName?: string; phone: string; email?: string }): Promise<Patient>;
  createService(input: { tenantId: string; branchId?: string; name: string; durationMinutes?: number; priceKobo?: number; currency?: Service['currency'] }): Promise<Service>;
  createAppointment(input: { tenantId: string; branchId: string; patientId: string; startsAt: string; serviceName: string; doctorMemberId?: string; notes?: string }): Promise<Appointment>;
  visibleBranchesForMember(memberId: string): Promise<Branch[]>;
  getTenantSnapshot(tenantId: string): Promise<TenantSnapshot>;
  seedCelonDemo(): Promise<TenantSnapshot>;
}

export function createMemoryStore(): MemoryStore {
  const tenants = new Map<string, Tenant>();
  const branches = new Map<string, Branch>();
  const members = new Map<string, Member>();
  const patients = new Map<string, Patient>();
  const services = new Map<string, Service>();
  const appointments = new Map<string, Appointment>();

  async function getTenantSnapshot(tenantId: string): Promise<TenantSnapshot> {
    const tenant = tenants.get(tenantId);
    if (!tenant) throw new Error('TENANT_NOT_FOUND');
    return {
      tenant,
      branches: [...branches.values()].filter((item) => item.tenantId === tenantId),
      members: [...members.values()].filter((item) => item.tenantId === tenantId),
      patients: [...patients.values()].filter((item) => item.tenantId === tenantId),
      appointments: [...appointments.values()].filter((item) => item.tenantId === tenantId),
    };
  }

  const store: MemoryStore = {
    async createTenant(input) {
      const tenant: Tenant = { id: nanoid(), name: input.name, slug: input.slug, status: 'trial', createdAt: now() };
      tenants.set(tenant.id, tenant);
      return tenant;
    },
    async createBranch(input) {
      if (!tenants.has(input.tenantId)) throw new Error('TENANT_NOT_FOUND');
      const branch: Branch = { id: nanoid(), tenantId: input.tenantId, name: input.name, address: input.address, phone: input.phone, status: 'active', createdAt: now() };
      branches.set(branch.id, branch);
      return branch;
    },
    async addMember(input) {
      if (!tenants.has(input.tenantId)) throw new Error('TENANT_NOT_FOUND');
      const member: Member = { id: nanoid(), tenantId: input.tenantId, email: input.email.toLowerCase(), displayName: input.displayName, role: input.role, branchIds: input.branchIds ?? [], status: 'active', createdAt: now() };
      members.set(member.id, member);
      return member;
    },
    async createPatient(input) {
      if (!tenants.has(input.tenantId)) throw new Error('TENANT_NOT_FOUND');
      const patient: Patient = { id: nanoid(), tenantId: input.tenantId, patientCode: patientCode(), firstName: input.firstName, lastName: input.lastName, phone: input.phone, email: input.email?.toLowerCase(), createdAt: now() };
      patients.set(patient.id, patient);
      return patient;
    },
    async createService(input) {
      const service: Service = { id: nanoid(), tenantId: input.tenantId, branchId: input.branchId, name: input.name, durationMinutes: input.durationMinutes ?? 30, priceKobo: input.priceKobo ?? 0, currency: input.currency ?? 'NGN', active: true };
      services.set(service.id, service);
      return service;
    },
    async createAppointment(input) {
      if (!tenants.has(input.tenantId)) throw new Error('TENANT_NOT_FOUND');
      if (!branches.has(input.branchId)) throw new Error('BRANCH_NOT_FOUND');
      if (!patients.has(input.patientId)) throw new Error('PATIENT_NOT_FOUND');
      const appointment: Appointment = { id: nanoid(), tenantId: input.tenantId, branchId: input.branchId, patientId: input.patientId, doctorMemberId: input.doctorMemberId, serviceName: input.serviceName, startsAt: input.startsAt, status: 'requested', notes: input.notes, createdAt: now() };
      appointments.set(appointment.id, appointment);
      return appointment;
    },
    async visibleBranchesForMember(memberId) {
      const member = members.get(memberId);
      if (!member) throw new Error('MEMBER_NOT_FOUND');
      const all = [...branches.values()].filter((branch) => branch.tenantId === member.tenantId);
      if (member.role === 'owner' || member.role === 'admin' || member.branchIds.length === 0) return all;
      return all.filter((branch) => member.branchIds.includes(branch.id));
    },
    getTenantSnapshot,
    async seedCelonDemo() {
      const tenant = await store.createTenant({ name: 'Celon Dental Clinic', slug: 'celon-dental' });
      const lekki = await store.createBranch({ tenantId: tenant.id, name: 'Lekki Branch', address: 'Lekki, Lagos' });
      const ikeja = await store.createBranch({ tenantId: tenant.id, name: 'Ikeja Branch', address: 'Ikeja, Lagos' });
      await store.addMember({ tenantId: tenant.id, email: 'owner@celondentalclinic.com', role: 'owner', displayName: 'Clinic Owner' });
      await store.addMember({ tenantId: tenant.id, branchIds: [lekki.id, ikeja.id], email: 'doctor@celondentalclinic.com', role: 'doctor', displayName: 'Lead Dentist' });
      await store.createService({ tenantId: tenant.id, name: 'Dental Consultation', durationMinutes: 30, priceKobo: 1500000 });
      const patient = await store.createPatient({ tenantId: tenant.id, firstName: 'Demo', lastName: 'Patient', phone: '+2348000000000' });
      await store.createAppointment({ tenantId: tenant.id, branchId: lekki.id, patientId: patient.id, startsAt: new Date(Date.now() + 86400000).toISOString(), serviceName: 'Dental Consultation' });
      return getTenantSnapshot(tenant.id);
    },
  };

  return store;
}
