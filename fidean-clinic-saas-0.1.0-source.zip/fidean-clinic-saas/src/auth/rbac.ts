import type { Permission, Role } from '../domain/types.js';

const matrix: Record<Role, Permission[]> = {
  owner: ['manage_subscription', 'manage_staff', 'manage_branches', 'manage_appointments', 'create_appointment', 'view_patients', 'write_encounter', 'view_billing', 'manage_billing', 'view_reports'],
  admin: ['manage_staff', 'manage_branches', 'manage_appointments', 'create_appointment', 'view_patients', 'write_encounter', 'view_billing', 'manage_billing', 'view_reports'],
  branch_manager: ['manage_appointments', 'create_appointment', 'view_patients', 'write_encounter', 'view_billing', 'view_reports'],
  doctor: ['view_patients', 'write_encounter', 'create_appointment'],
  receptionist: ['create_appointment', 'view_patients'],
  nurse: ['view_patients', 'write_encounter'],
  accountant: ['view_billing', 'manage_billing', 'view_reports'],
  viewer: ['view_patients', 'view_reports'],
};

export function canPerform(role: Role, permission: Permission): boolean {
  return matrix[role]?.includes(permission) ?? false;
}

export function assertCan(role: Role, permission: Permission): void {
  if (!canPerform(role, permission)) {
    const error = new Error(`Role ${role} cannot ${permission}`);
    (error as Error & { statusCode?: number }).statusCode = 403;
    throw error;
  }
}
